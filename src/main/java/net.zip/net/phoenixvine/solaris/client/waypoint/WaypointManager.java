package net.phoenixvine.solaris.client.waypoint;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.MinecraftForge;
import net.phoenixvine.solaris.api.SolarisAPI;
import net.phoenixvine.solaris.api.SolarisFeatureState;
import net.phoenixvine.solaris.api.event.WaypointEvent;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

public final class WaypointManager {

    private WaypointManager() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
    private static final Set<String> HIDDEN_CATEGORIES = new TreeSet<>();
    private static String trackedId = null;
    private static String loadedWorldKey = null;

    private static final class SaveData {

        List<Waypoint> waypoints = new ArrayList<>();
        List<String> hiddenCategories = new ArrayList<>();
        String trackedId;
    }

    public static List<Waypoint> getAll() {
        ensureLoaded();
        return WAYPOINTS;
    }

    public static List<Waypoint> getVisibleForDimension(ResourceLocation dimension) {
        ensureLoaded();
        if (!SolarisAPI.getFeatureState(SolarisAPI.FEATURE_WAYPOINTS, dimension).atLeast(SolarisFeatureState.VISIBLE)) {
            return List.of();
        }

        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : WAYPOINTS) {
            if (w.visible && w.dimension.equals(dimension.toString()) &&
                    !HIDDEN_CATEGORIES.contains(w.categoryOrEmpty())) {
                out.add(w);
            }
        }
        for (Waypoint marker : TransientMarkers.collect(dimension)) {
            if (!HIDDEN_CATEGORIES.contains(marker.categoryOrEmpty())) out.add(marker);
        }
        return out;
    }

    public static boolean canPlace(ResourceLocation dimension) {
        return SolarisAPI.getFeatureState(SolarisAPI.FEATURE_WAYPOINTS, dimension).atLeast(SolarisFeatureState.ENABLED);
    }

    private static final long PLACE_COOLDOWN_NANOS = 500_000_000L;
    private static long lastPlacementNanos = System.nanoTime() - PLACE_COOLDOWN_NANOS;

    public static boolean tryBeginPlacement() {
        long now = System.nanoTime();
        if (now - lastPlacementNanos < PLACE_COOLDOWN_NANOS) return false;
        lastPlacementNanos = now;
        return true;
    }

    public static void add(Waypoint waypoint) {
        ensureLoaded();
        WAYPOINTS.add(waypoint);
        save();
        MinecraftForge.EVENT_BUS.post(new WaypointEvent.Added(waypoint));
    }

    public static boolean remove(String id) {
        ensureLoaded();
        Waypoint target = null;
        for (Waypoint w : WAYPOINTS) {
            if (w.id.equals(id)) {
                target = w;
                break;
            }
        }
        if (target == null) return false;

        WaypointEvent.Removed event = new WaypointEvent.Removed(target);
        MinecraftForge.EVENT_BUS.post(event);
        if (event.isCanceled()) return false;

        WAYPOINTS.remove(target);
        if (id.equals(trackedId)) trackedId = null;
        save();
        return true;
    }

    public static void removeByName(String name) {
        ensureLoaded();
        WAYPOINTS.removeIf(w -> {
            boolean match = w.name.equals(name);
            if (match && w.id.equals(trackedId)) trackedId = null;
            return match;
        });
        save();
    }

    public static List<String> getCategories() {
        ensureLoaded();
        Set<String> categories = new TreeSet<>();
        categories.add("");
        for (Waypoint w : WAYPOINTS) categories.add(w.categoryOrEmpty());
        return new ArrayList<>(categories);
    }

    public static boolean isCategoryHidden(String category) {
        ensureLoaded();
        return HIDDEN_CATEGORIES.contains(category);
    }

    public static void setCategoryHidden(String category, boolean hidden) {
        ensureLoaded();
        if (hidden) HIDDEN_CATEGORIES.add(category);
        else HIDDEN_CATEGORIES.remove(category);
        save();
    }

    public static Waypoint getTracked() {
        ensureLoaded();
        if (trackedId == null) return null;
        for (Waypoint w : WAYPOINTS) {
            if (w.id.equals(trackedId)) return w;
        }
        return null;
    }

    public static void setTracked(String id) {
        ensureLoaded();
        trackedId = id;
        save();
    }

    public static void save() {
        String key = currentWorldKey();
        if (key == null || !key.equals(loadedWorldKey)) return;
        try {
            SaveData data = new SaveData();
            data.waypoints = WAYPOINTS;
            data.hiddenCategories = new ArrayList<>(HIDDEN_CATEGORIES);
            data.trackedId = trackedId;

            Path file = fileFor(key);
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(data));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void ensureLoaded() {
        String key = currentWorldKey();
        if (key == null || key.equals(loadedWorldKey)) return;

        WAYPOINTS.clear();
        HIDDEN_CATEGORIES.clear();
        trackedId = null;
        try {
            Path file = fileFor(key);
            if (Files.exists(file)) {
                String json = Files.readString(file);
                try {
                    SaveData data = GSON.fromJson(json, SaveData.class);
                    if (data != null) {
                        if (data.waypoints != null) WAYPOINTS.addAll(data.waypoints);
                        if (data.hiddenCategories != null) HIDDEN_CATEGORIES.addAll(data.hiddenCategories);
                        trackedId = data.trackedId;
                    }
                } catch (JsonSyntaxException e) {

                    Type type = new TypeToken<List<Waypoint>>() {}.getType();
                    List<Waypoint> legacy = GSON.fromJson(json, type);
                    if (legacy != null) WAYPOINTS.addAll(legacy);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        loadedWorldKey = key;
    }

    private static Path fileFor(String worldKey) {
        String safe = worldKey.replaceAll("[^a-zA-Z0-9._-]", "_");
        return Paths.get("config", "solaris", "waypoints", safe + ".json");
    }

    public static Path currentWaypointsFile() {
        String key = currentWorldKey();
        return key == null ? null : fileFor(key);
    }

    private static String cachedWorldKey = null;
    private static boolean cachedWorldKeyValid = false;
    private static Object cachedWorldKeyOwner = null;

    public static String currentWorldKey() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            cachedWorldKeyValid = false;
            return null;
        }

        Object owner = mc.getCurrentServer() != null ? mc.getCurrentServer() : mc.getSingleplayerServer();
        if (cachedWorldKeyValid && owner == cachedWorldKeyOwner) return cachedWorldKey;

        ServerData server = mc.getCurrentServer();
        String key;
        if (server != null) {
            key = "mp-" + server.ip;
        } else if (mc.hasSingleplayerServer() && mc.getSingleplayerServer() != null) {
            Path root = mc.getSingleplayerServer().getWorldPath(LevelResource.ROOT);
            long seed = mc.getSingleplayerServer().overworld().getSeed();
            key = "sp-" + singleplayerWorldId(root, seed);
        } else {
            key = "unknown";
        }

        cachedWorldKey = key;
        cachedWorldKeyOwner = owner;
        cachedWorldKeyValid = true;
        return key;
    }

    private static final String WORLD_ID_FILE = "solaris_world_id.txt";

    private static String singleplayerWorldId(Path worldRoot, long seed) {
        Path idFile = worldRoot.resolve(WORLD_ID_FILE);
        try {
            if (Files.exists(idFile)) {
                String existing = Files.readString(idFile).trim();
                int sep = existing.indexOf('|');
                if (sep > 0) {
                    String storedId = existing.substring(0, sep);
                    try {
                        long storedSeed = Long.parseLong(existing.substring(sep + 1));
                        if (storedSeed == seed && !storedId.isEmpty()) return storedId;
                    } catch (NumberFormatException ignored) {

                    }
                }
            }
            String fresh = UUID.randomUUID().toString();
            Files.createDirectories(worldRoot);
            Files.writeString(idFile, fresh + "|" + seed);
            return fresh;
        } catch (IOException e) {

            return worldRoot.toAbsolutePath().normalize().toString();
        }
    }
}
